package mta.check.osfsa;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;

import laser.fsainterface.RunnableFSAInterface;
import laser.fsa.RunnableFSA;
import laser.alphabet.StringLabel;

import mta.check.fsa.ResultCollector;

import sofya.base.MethodSignature;
import sofya.base.exceptions.BadFileFormatException;
import sofya.ed.semantic.SemanticDataHandler;
import sofya.ed.semantic.ThreadFilter;
import sofya.ed.semantic.ObjectFilter;
import sofya.ed.semantic.SemanticEventDispatcher;
import sofya.ed.semantic.SemanticEventDispatcher.InternalException;

/**
 * <p>Runs a program and checks that the per-object call sequences conform
 * to a Propel generated finite state automata (FSA) specification.
 * <ul>
 * <li>Argument 1: Module data file</li>
 * <li>Argument 2: FSA file</li>
 * <li>Argument 3: Main class</li>
 * </ul>
 * </p>
 *
 * @author Matthew Dwyer
 */
public class OSFSAChecker {
    public OSFSAChecker() {
    }

    public static void main(String[] argv) {
        if (argv.length < 3) {
            printUsage(null);
        }

        SemanticEventDispatcher ed = new SemanticEventDispatcher();

        SemanticDataHandler sdh = new SemanticDataHandler();
        try {
            ed.setEDData(sdh.readDataFile(argv[0]));
        }
        catch (BadFileFormatException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        RunnableFSAInterface<StringLabel> fsa = null;
        try {
            // FSAs exported from Propel are stored as RunnableFSAs defined
            // using StringLabels
            Object o = RunnableFSA.readPersistent(argv[1]);
            if (o instanceof RunnableFSAInterface) {
                fsa = (RunnableFSAInterface<StringLabel>) o;
            }
            else {
                System.err.println("FSA not RunnableFSAInterface<StringLabel>");
                System.exit(1);
            }

            if (!fsa.isDeterministic()) {
                System.err.println("FSA must be deterministic");
                System.exit(1);
            }
        }
        catch (java.lang.Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        ResultCollector results = new ResultCollector();
        PatternSearcherFactory searcherFactory =
            new PatternSearcherFactory(fsa, results);
        ed.addEventListener(new ObjectFilter(searcherFactory));

        ed.setMainClass(argv[2]);

        for (int i = 3; i < argv.length; i++) {
            ed.addArgument(argv[i]);
        }

        try {
            ed.startDispatcher();
        }
        catch (IllegalStateException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (InternalException e) {
            Throwable cause = e.getCause();
            if (cause != null) {
                cause.printStackTrace();
            }
            System.err.println(e.getMessage());
            System.exit(1);
        }

        System.out.println();
        System.out.println("Is error trace: " + results.isErrorRun());
        System.out.println();
    }

    private static final void printUsage(String msg) {
        System.err.println();
        if (msg != null) {
            System.err.println(msg);
        }
        System.err.println("TODO: Show my usage");
        System.exit(1);
    }
}
