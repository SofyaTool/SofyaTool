package mta.check.fsa;

/**
 * <p>Records the results of FSA checking.</p>
 *
 * @author Matthew Dwyer
 */
public final class ResultCollector {
    private boolean isErrorRun = false;

    public ResultCollector() {
    }

    public boolean isErrorRun() {
        return isErrorRun;
    }

    public void isErrorRun(boolean flag) {
        // if any error is reported then we keep that
        this.isErrorRun |= flag;
    }
}
