import laser.fsainterface.RunnableFSAInterface;
import laser.fsa.RunnableFSA;
import laser.alphabetinterface.AlphabetInterface;
import laser.alphabetinterface.AlphabetInterfaceException;
import laser.alphabet.StringLabel;
import laser.util.PersistentException;

import java.util.Iterator;

/**
 * <p>Prints a Propel generated finite state automata (FSA).
 * <ul>
 * <li>Argument 1: FSA file</li>
 * </ul>
 * </p>
 *
 * @author Matthew Dwyer
 */
public class FSAPrinter {
    public static void main(String[] argv) {
        try {
            RunnableFSAInterface<StringLabel> fsa =
                (RunnableFSAInterface<StringLabel>)
                    RunnableFSA.readPersistent(argv[0]);
            //fsa.toDot("fsa.dot");
            System.out.println("FSA is deterministic? " + fsa.isDeterministic());

            AlphabetInterface<StringLabel> alpha = fsa.getAlphabet();
            System.out.println("Alphabet for FSA is:");
            Iterator<StringLabel> alphaIt = alpha.sortedIterator();
            while (alphaIt.hasNext()) {
                StringLabel label = (StringLabel)alphaIt.next();
                System.out.println("  "+label);
            }

            StringLabel sl = alpha.createLabelInterface("TestClass:open");
            System.out.println("Alphabet contains TestClass:open? " + alpha.contains(sl));

            sl = alpha.createLabelInterface("TestClass:peek");
            System.out.println("Alphabet contains TestClass:peek? " + alpha.contains(sl));
        }
        catch (java.lang.Exception e) {
            e.printStackTrace();
        }
    }
}
