package mta.check.fsa;

import laser.fsainterface.RunnableFSAInterface;
import laser.alphabet.StringLabel;

import sofya.ed.semantic.*;
import sofya.ed.semantic.EventListener.*;

/**
 * <p>Instantiates instances of the FSA pattern checker to be used on
 * a per-thread basis.</p>
 *
 * @author Matthew Dwyer
 */
public final class PatternSearcherFactory
        implements ChainedEventListenerFactory {
    private RunnableFSAInterface<StringLabel> fsa;
    private ResultCollector results;

    private PatternSearcherFactory() {
    }

    public PatternSearcherFactory(RunnableFSAInterface<StringLabel> fsa,
                                  ResultCollector results) {
        this.fsa = fsa;
        this.results = results;
    }

    public ChainedEventListener createEventListener(ChainedEventListener
            parent, long streamId, String streamName)
            throws FactoryException {
        return new PatternSearcher(parent, streamId, streamName,
                                   fsa, results);
    }
}
