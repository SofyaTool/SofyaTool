package mta.check.osfsa;

import java.util.SortedSet;
import java.util.Iterator;

import laser.fsainterface.RunnableFSAInterface;
import laser.fsainterface.FSAStateInterface;
import laser.fsainterface.FSAInterfaceException;
import laser.alphabetinterface.AlphabetInterface;
import laser.alphabetinterface.AlphabetInterfaceException;
import laser.alphabet.StringLabel;

import mta.check.fsa.ResultCollector;

import sofya.base.MethodSignature;
import sofya.ed.semantic.EventListener;
import sofya.ed.semantic.EventListener.*;
import sofya.ed.semantic.ChainedEventListener;
import sofya.ed.semantic.EventSelectionFilter;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.Type;

/**
 * Object-sensitive FSA checker.
 *
 * @author Matthew Dwyer
 * @version 03/13/2006
 */
public final class PatternSearcher
        extends EventSelectionFilter
        implements ChainedEventListener {
    private ResultCollector results;

    private RunnableFSAInterface<StringLabel> fsa;
    private AlphabetInterface<StringLabel> alphabet;
    private FSAStateInterface<StringLabel> currentState;

    private ChainedEventListener parent;
    private long streamId;
    private String streamName;

    private PatternSearcher() {
    }

    public PatternSearcher(RunnableFSAInterface<StringLabel> fsa,
                           ResultCollector results) {
        this.fsa = fsa;
        this.results = results;
        this.currentState = fsa.getStartState();
        this.alphabet = fsa.getAlphabet();
        System.out.println(">In constructor " + this);
    }

    public PatternSearcher(ChainedEventListener parent, long streamId,
                           String streamName, 
                           RunnableFSAInterface<StringLabel> fsa,
                           ResultCollector results) {
        this(fsa, results);
        this.parent = parent;
        this.streamId = streamId;
        this.streamName = streamName;
    }

    private void process(MethodData method) {
        // short-circuit processing if FSA is in sink state
        // NB: this is currently unsupported in the FSA API
        // if (currentState.isSink()) return;

        // Access the call data to determine the class and
        // method name to construct the string for the label
        String className = method.getSignature().getClassName();
        String methodName = method.getSignature().getMethodName();

        StringLabel sl = null;
        try {
            sl = alphabet.createLabelInterface(className + ":" + methodName);
        }
        catch(AlphabetInterfaceException aie) {
            System.err.println("Alphabet lookup error");
            return;
        }

        // if this is an unobservable call skip it
        if (!alphabet.contains(sl)) return;

        SortedSet<FSAStateInterface<StringLabel>> succs = null;
        try {
            succs = fsa.getSuccessorStates(currentState, sl);
        }
        catch(FSAInterfaceException fie) {
            System.err.println("FSA transition error");
            return;
        }

        System.out.println(">In process " + this);
        System.out.println(">FSA Transitioning from state " + currentState);
        System.out.println(">   on symbol " + sl);

        // we assume this is a singleton set since we've already
        // check for FSA determinism

        // update current state
        currentState = succs.first();
        System.out.println(">   to state " + currentState);
    }

    public void systemExited() {
        System.out.println(">In systemExited " + this);
        System.out.println(">FSA is " + fsa);
        System.out.println(">Exiting in state " + currentState);
        System.out.println(">   which is a" +
            (currentState.isAccept() ? "n accept state"
                                     : " non-accept state"));
        results.isErrorRun(!currentState.isAccept());
    }

    public void virtualMethodEnterEvent(ThreadData threadData, 
                                        ObjectData objectData,
                                        MethodData methodData) {
        System.out.println(">In virtualMethodEnterEvent " + this);
        process(methodData);
    }

    public void constructorEnterEvent(ThreadData threadData, 
                                      ObjectData objectData,
                                      MethodData methodData) {
        System.out.println(">In constructorEnterEvent " + this);
    }

    public void callReturnEvent(ThreadData threadData, CallData callData,
                                boolean exceptional) {
    }

    public ChainedEventListener getParent() {
        return parent;
    }

    public long getStreamID() {
        return streamId;
    }

    public String getStreamName() {
        return streamName;
    }
}
