public class TestClass {
    public static void main(String[] argv) {
       TestClass tc1 = new TestClass();
       TestClass tc2= new TestClass();
       TestClass tc3= new TestClass();
       tc1.open();
       tc1.read();
       tc2.open();
       tc1.read();
       tc2.read();
       tc1.close();
       tc2.read();
       tc2.close();
    }
    
    void open() {
        System.out.println("Open");
    }

    void close() {
        System.out.println("Close");
    }
    
    void read() {
        System.out.println(" Read");
    }

    void write() {
        System.out.println(" Write");
    }
}
