#!/bin/bash

javac TestClass.java
java sofya.ed.semantic.SemanticInstrumentor TestClass-mod
java mta.check.fsa.FSAChecker TestClass-mod.eg.dat OpenClose.fsa TestClass >FSA.log
javac TestClass.java
java sofya.ed.semantic.SemanticInstrumentor TestClassOS-mod
java mta.check.osfsa.OSFSAChecker TestClassOS-mod.eg.dat OpenClose.fsa TestClass >OSFSA.log

