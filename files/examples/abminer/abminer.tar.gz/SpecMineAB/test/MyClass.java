public class MyClass {
    private static boolean cond = true;
    
    public static void main(String[] argv) {
        for (int i = 0; i < 2; i++) {
            try {
                if (i % 2 == 1) {
                    throw new Exception();
                }
                doWork();
                canThrowException();
            }
            catch (Exception e) {
                printMessage("An error");
                cleanupWork();
                report();
            }
        }
    }
    
    private static void doWork() {
        System.out.println("Working...");
    }
    
    private static void canThrowException() throws Exception {
        System.out.println("Possible exception throwing work...");
        if (cond) {
            throw new Exception("Uh-oh");
        }
        System.out.println("Succeeded...");
    }
    
    private static void cleanupWork() {
        System.out.println("Cleaning up...");
    }
    
    private static void printMessage(String str) {
        System.err.println(str);
    }
    
    private static void report() {
        System.err.println("Reporting");
    }
}
