package mta.mining.ab;

/**
 * <p>Exception thrown to indicate that information is not available about
 * a particular call site. This indicates that it is not possible to
 * determine whether a call occurs in exceptional cleanup code.</p>
 *
 * @author Alex Kinneer
 */
public class NoInformationException extends Exception {
    public NoInformationException() {
        super();
    }

    public NoInformationException(String message) {
        super(message);
    }

    public NoInformationException(Throwable cause) {
        super(cause);
    }

    public NoInformationException(String message, Throwable cause) {
        super(message, cause);
    }
}
