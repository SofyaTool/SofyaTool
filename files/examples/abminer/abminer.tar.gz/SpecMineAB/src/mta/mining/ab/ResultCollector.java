package mta.mining.ab;

import java.util.Map;
import java.util.Set;

import sofya.base.MethodSignature;

import gnu.trove.THashMap;

/**
 * <p>Collects the candidate <i>(ab)*</i> patterns found in the
 * program.</p>
 *
 * @author Alex Kinneer
 */
public final class ResultCollector {
    private Map patternCandidates = new THashMap();
    private boolean isErrorRun = false;

    public ResultCollector() {
    }

    public Map getCandidatePatterns() {
        return patternCandidates;
    }

    public boolean isErrorRun() {
        return isErrorRun;
    }

    protected void isErrorRun(boolean flag) {
        this.isErrorRun = flag;
    }

    protected void addCandidates(MethodSignature a, Set bs) {
        // We should only reach here if A has been seen before, which
        // means we have seen (AA). We 'lock' the set for that A,
        // so only the B's seen in between the two A's are
        // candidates. From then on, the set of candidate B's
        // can only be reduced.

        Set current_bs = (Set) patternCandidates.get(a);
        if (current_bs == null) {
            patternCandidates.put(a, bs);
        }
        else {
            // Intersect the existing maximal candidates with the
            // current set of maximal candidates.
            current_bs.retainAll(bs);
        }
    }
}
