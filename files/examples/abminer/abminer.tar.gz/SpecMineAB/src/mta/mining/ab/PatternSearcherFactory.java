package mta.mining.ab;

import sofya.ed.semantic.*;
import sofya.ed.semantic.EventListener.*;

/**
 * <p>A factory for <i>(ab)*</i> pattern searchers. Used to create a separate
 * pattern searcher for each thread's event stream. This ensures that
 * candidate patterns can only be derived from the call events on individual
 * threads.</p>
 *
 * @author Alex Kinneer
 */
public final class PatternSearcherFactory
        implements ChainedEventListenerFactory {
    private CleanupCallFinder callChecker;
    private ResultCollector results;

    private PatternSearcherFactory() {
    }

    public PatternSearcherFactory(CleanupCallFinder callChecker,
                                  ResultCollector results) {
        this.callChecker = callChecker;
        this.results = results;
    }

    public ChainedEventListener createEventListener(ChainedEventListener
            parent, long streamId, String streamName) throws
            FactoryException {
        return new PatternSearcher(parent, streamId, streamName,
                                   callChecker, results);
    }
}
