package mta.mining.ab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

import antlr.*;

import gnu.trove.THashMap;
import gnu.trove.TIntHashSet;
import gnu.trove.TIntIterator;

/**
 * <p>Finds calls made in &quot;cleanup&quot; blocks of code; that is,
 * exception handlers and finally blocks.</p>
 *
 * <p>Uses an instrumented ANTLR parser to identify such calls.</p>
 *
 * @author Alex Kinneer
 */
public final class CleanupCallFinder {
    private Map classCallData = new THashMap();

    public CleanupCallFinder() {
    }

    public final boolean isCleanupCall(String source, int line)
            throws NoInformationException {
        TIntHashSet cleanupCalls = (TIntHashSet) classCallData.get(source);

        if (cleanupCalls == null) {
            throw new NoInformationException();
        }

        return cleanupCalls.contains(line);
    }

    public final void findCleanupCalls(List sourceFiles)
            throws ParserException {
        JavaRecognizer parser;

        Iterator iterator = sourceFiles.iterator();
        int size = sourceFiles.size();
        for (int i = size; i-- > 0; ) {
            String file = (String) iterator.next();

            BufferedReader fileIn = null;
            try {
                fileIn = new BufferedReader(new FileReader(file));
                parser = new JavaRecognizer(new JavaLexer(fileIn));
            }
            catch (FileNotFoundException e) {
                throw new ParserException("Input file '" + file + "' not " +
                                          "found", e);
            }

            int lastSlash = file.lastIndexOf('/');
            String shortName = file.substring(lastSlash + 1);

            try {
                classCallData.put(shortName, parser.scanCompilationUnit());
            }
            catch (TokenStreamException e) {
                throw new ParserException("Unable to read '" + file + "'", e);
            }
            catch (RecognitionException e) {
                throw new ParserException("Unable to read '" + file + "'", e);
            }
            finally {
                try {
                    fileIn.close();
                }
                catch (IOException e) {
                    // Why did Sun think this exception needed to be thrown?
                }
            }
        }
    }
}
