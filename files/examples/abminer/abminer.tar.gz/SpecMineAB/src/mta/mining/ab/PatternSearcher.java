package mta.mining.ab;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import com.sun.jdi.ObjectReference;

import sofya.base.MethodSignature;
import sofya.ed.semantic.EventListener;
import sofya.ed.semantic.EventListener.*;
import sofya.ed.semantic.ChainedEventListener;
import sofya.ed.semantic.EventSelectionFilter;

import gnu.trove.THashMap;
import gnu.trove.THashSet;
import gnu.trove.TObjectHashingStrategy;

import org.apache.bcel.Constants;
import org.apache.bcel.generic.Type;

/**
 * <p>Searches for candidate <i>(ab)*</i> patterns.</p>
 *
 * @author Alex Kinneer
 * @version 02/21/2006
 */
public final class PatternSearcher extends EventSelectionFilter
        implements ChainedEventListener {
    private CleanupCallFinder callChecker;
    private ResultCollector results;

    // Initialized on executionStarted event

    private Map candidates;
    private Set aTypes;

    private ChainedEventListener parent;
    private long streamId;
    private String streamName;

    private PatternSearcher() {
    }

    public PatternSearcher(CleanupCallFinder callChecker,
                           ResultCollector results) {
        this.callChecker = callChecker;
        this.results = results;

        candidates = new THashMap(new CallHashingStrategy());
        aTypes = new THashSet();
    }

    public PatternSearcher(ChainedEventListener parent, long streamId,
                           String streamName, CleanupCallFinder callChecker,
                           ResultCollector results) {
        this(callChecker, results);
        this.parent = parent;
        this.streamId = streamId;
        this.streamName = streamName;
    }

    private void process(CallData call) {
        if (!candidates.containsKey(call)) {
            candidates.put(call, new THashSet());
        }

        Iterator iterator = candidates.keySet().iterator();
        int size = candidates.size();

        a_loop:
        for (int i = size; i-- > 0; ) {
            CallData a = (CallData) iterator.next();
            MethodSignature aSig = a.getCalledSignature();

            if (a.getCalledSignature().equals(call.getCalledSignature())) {

                // If we just added it as a candidate A, don't treat it as
                // a candidate B to itself
                if (a == call) {
                    continue;
                }

                results.addCandidates(aSig, (Set) candidates.get(a));
                candidates.put(a, new THashSet());
            }
            else {
                MethodSignature bSig = call.getCalledSignature();

                // Check that A and B are in the same package. This should be
                // extended to define "package groups" in the future, to allow
                // users to specify related packages as described in the paper
                String aClass = aSig.getClassName();
                String bClass = bSig.getClassName();
                int lastDot = aClass.lastIndexOf('.');
                String aPackage = (lastDot != -1)
                                  ? aClass.substring(0, lastDot)
                                  : "";
                lastDot = bClass.lastIndexOf('.');
                String bPackage = (lastDot != -1)
                                  ? bClass.substring(0, lastDot)
                                  : "";
                if (!aPackage.equals(bPackage)) {
                    continue;
                }

                // Check the lightweight dataflow requirement: every
                // non-primitive value and receiver object in B must
                // also be in A
                Arguments aArgs = a.getArguments();
                Arguments bArgs = call.getArguments();
                ObjectReference aThis = aArgs.getThis();
                ObjectReference bThis = bArgs.getThis();

                aTypes.clear();
                aTypes.add(aSig.getReturnType());
                Type[] argTypes = aSig.getArgumentTypes();
                for (int j = 0; j < argTypes.length; j++) {
                    aTypes.add(argTypes[j]);
                }
                if (aThis != null) {
                    aTypes.add(Type.getType(
                            aThis.referenceType().signature()));
                }

                Type bRetType = bSig.getReturnType();
                if ((bRetType.getType() == Constants.T_OBJECT)
                        && !aTypes.contains(bSig.getReturnType())) {
                    continue;
                }

                argTypes = bSig.getArgumentTypes();
                for (int j = 0; j < argTypes.length; j++) {
                    if ((argTypes[j].getType() == Constants.T_OBJECT)
                            && !aTypes.contains(argTypes[j])) {
                        continue a_loop;
                    }
                }

                if (bThis != null) {
                    Type bReceiverType = Type.getType(
                            bThis.referenceType().signature());
                    if ((bReceiverType.getType() == Constants.T_OBJECT)
                            && !aTypes.contains(bReceiverType)) {
                        continue;
                    }
                }

                // If we meet requirements, add this B to the candidates
                // set for the current A
                Set bs = (Set) candidates.get(a);
                try {
                    boolean isCleanup = callChecker.isCleanupCall(
                            call.getSourceFile(), call.getLineNumber());
                    bs.add(new CandidateB(bSig, isCleanup));
                }
                catch (NoInformationException e) {
                    System.err.println("TODO: Log me - no information error!");
                }
            }
        }
    }

    public void systemExited() {
        // Merge all pending sets of candidate B's into the associated
        // 'locked' (final) sets of candidates
        Iterator iterator = candidates.keySet().iterator();
        int size = candidates.size();

        for (int i = size; i-- > 0; ) {
            CallData a = (CallData) iterator.next();
            MethodSignature aSig = a.getCalledSignature();

            results.addCandidates(aSig, (Set) candidates.get(a));
            iterator.remove();
        }
    }

    public void staticCallEvent(ThreadData threadData, CallData callData) {
        /*System.out.println(callData.getRawCalledSignature() + ", " +
                           callData.getSourceFile() + ": " +
                           callData.getLineNumber());
        try {
            System.out.println("\t" + callChecker.isCleanupCall(
                    callData.getSourceFile(), callData.getLineNumber()));
        }
        catch (NoInformationException e) {
            System.err.println("No information!!");
        }*/

        process(callData);
    }

    public void virtualCallEvent(ThreadData threadData, CallData callData) {
        /*System.out.println(callData.getRawCalledSignature() + ", " +
                           callData.getSourceFile() + ": " +
                           callData.getLineNumber());
        try {
            System.out.println("\t" + callChecker.isCleanupCall(
                    callData.getSourceFile(), callData.getLineNumber()));
        }
        catch (NoInformationException e) {
            System.err.println("No information!!");
        }*/

        process(callData);
    }

    public void interfaceCallEvent(ThreadData threadData, CallData callData) {
        /*System.out.println(callData.getRawCalledSignature() + ", " +
                           callData.getSourceFile() + ": " +
                           callData.getLineNumber());
        try {
            System.out.println("\t" + callChecker.isCleanupCall(
                    callData.getSourceFile(), callData.getLineNumber()));
        }
        catch (NoInformationException e) {
            System.err.println("No information!!");
        }*/

        process(callData);
    }

    public void callReturnEvent(ThreadData threadData, CallData callData,
                                boolean exceptional) {
        if (exceptional) {
            results.isErrorRun(true);
        }
    }

    public ChainedEventListener getParent() {
        return parent;
    }

    public long getStreamID() {
        return streamId;
    }

    public String getStreamName() {
        return streamName;
    }

    public static final class CandidateB {
        public final MethodSignature call;
        public final boolean isCleanup;
        private final int hashCode;

        private CandidateB() {
            throw new IllegalStateException("Illegal constructor");
        }

        public CandidateB(MethodSignature call, boolean isCleanup) {
            this.call = call;
            this.isCleanup = isCleanup;

            this.hashCode = call.hashCode() + ((isCleanup) ? 1 : 0);
        }

        public int hashCode() {
            return hashCode;
        }

        public boolean equals(Object o) {
            try {
                CandidateB cb = (CandidateB) o;
                return (cb.call.equals(this.call) &&
                        (cb.isCleanup == this.isCleanup));
            }
            catch (ClassCastException e) {
                return false;
            }
        }
    }

    private static final class CallHashingStrategy
            implements TObjectHashingStrategy {
        public int computeHashCode(Object o) {
            CallData cd = (CallData) o;
            return cd.getCalledSignature().hashCode();
        }

        public boolean equals(Object o1, Object o2) {
            try {
                CallData cd1 = (CallData) o1;
                CallData cd2 = (CallData) o2;

                return cd1.getCalledSignature().equals(
                        cd2.getCalledSignature());
            }
            catch (ClassCastException e) {
                System.err.println("TODO: log error");
                return o1.equals(o2);
            }
        }
    }
}
