package mta.mining.ab;

/**
 * <p>Exception thrown to indicate that there was a failure during parsing of
 * source code.</p>
 *
 * @author Alex Kinneer
 */
public class ParserException extends Exception {
    public ParserException() {
        super();
    }

    public ParserException(String message) {
        super(message);
    }

    public ParserException(Throwable cause) {
        super(cause);
    }

    public ParserException(String message, Throwable cause) {
        super(message, cause);
    }
}
