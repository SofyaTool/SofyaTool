package mta.mining.ab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;

import sofya.base.MethodSignature;
import sofya.base.exceptions.BadFileFormatException;
import sofya.ed.semantic.EDLHandler;
import sofya.ed.semantic.ThreadBasedSplitter;
import sofya.ed.semantic.SemanticEventDispatcher;
import sofya.ed.semantic.SemanticEventDispatcher.InternalException;

import mta.mining.ab.PatternSearcher.CandidateB;

/**
 * <p>Implementation of the Weimer and Necula technique for mining
 * <i>(ab)*</i> patterns of calls from programs using the heuristic
 * that <i>b</i>'s are likely to be found in exception handling
 * cleanup code.
 * <ul>
 * <li>Argument 1: Module data file</li>
 * <li>Argument 2: List of source files</li>
 * <li>Argument 3: Main class of program to be mined</li>
 * </ul>
 * </p>
 *
 * @author Alex Kinneer
 */
public class WNMiner {
    public WNMiner() {
    }

    public static void main(String[] argv) {
        if (argv.length < 3) {
            printUsage(null);
        }

        SemanticEventDispatcher ed = new SemanticEventDispatcher();

        EDLHandler edlHandler = new EDLHandler();
        try {
            ed.setEDData(edlHandler.readDataFile(argv[0]));
        }
        catch (BadFileFormatException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        CleanupCallFinder callFinder = new CleanupCallFinder();
        try {
            callFinder.findCleanupCalls(readSourceFiles(argv[1]));
        }
        catch (IOException e) {
            System.err.println("Could not read source file list: " +
                               e.getMessage());
            System.exit(1);
        }
        catch (ParserException e) {
            System.err.println(e.getMessage() + ": " +
                               e.getCause().getMessage());
            System.exit(1);
        }

        ResultCollector results = new ResultCollector();
        PatternSearcherFactory searcherFactory =
            new PatternSearcherFactory(callFinder, results);
        ed.addEventListener(new ThreadBasedSplitter(searcherFactory));

        //PatternSearcher ps = new PatternSearcher(callFinder, results);
        //eg.addEventListener(ps);

        ed.setMainClass(argv[2]);

        for (int i = 3; i < argv.length; i++) {
            ed.addArgument(argv[i]);
        }

        try {
            ed.startDispatcher();
        }
        catch (IllegalStateException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch (InternalException e) {
            Throwable cause = e.getCause();
            if (cause != null) {
                cause.printStackTrace();
            }
            System.err.println(e.getMessage());
            System.exit(1);
        }

        System.out.println();
        System.out.println("Is error trace: " + results.isErrorRun());
        System.out.println();

        Map candidatePatterns = results.getCandidatePatterns();
        Iterator aIterator = candidatePatterns.keySet().iterator();
        int aCount = candidatePatterns.size();
        for (int i = aCount; i-- > 0; ) {
            MethodSignature a = (MethodSignature) aIterator.next();
            Set bs = (Set) candidatePatterns.get(a);
            int bCount = bs.size();

            if (bCount == 0) continue;

            System.out.println("A: " + a + " ->");

            Iterator bIterator = bs.iterator();
            for (int j = bCount; j-- > 0; ) {
                CandidateB b = (CandidateB) bIterator.next();
                if (b.isCleanup) {
                    System.out.println("\tB: " + b.call + " [cleanup]");
                }
                else {
                    CandidateB cleanupB = new CandidateB(b.call, true);
                    if (bs.contains(cleanupB)) {
                        System.out.println("\tB: " + b.call);
                    }
                }
            }
            System.out.println();
        }
    }

    private static final List readSourceFiles(String f) throws IOException {
        List sourceFiles = new ArrayList();
        BufferedReader fIn = new BufferedReader(new FileReader(f));

        try {
            String line;
            while ((line = fIn.readLine()) != null) {
                sourceFiles.add(line);
            }
        }
        finally {
            try {
                fIn.close();
            }
            catch (IOException e) {
                // Don't care about this one
            }
        }

        return sourceFiles;
    }

    private static final void printUsage(String msg) {
        System.err.println();
        if (msg != null) {
            System.err.println(msg);
        }
        System.err.println("TODO: Show my usage");
        System.exit(1);
    }
}
